from .views import*
from django.urls  import path

urlpatterns = [
 
    path("",login,name='login'),
    path("signup/",signup,name='signup'),
    path("index/",index,name='index'),
    path('car/',car,name='car'),
    path('car_details/<int:car_id>/',car_details, name = 'car_details'),
    path('aboutus/',aboutus,name='aboutus'),
    path('contact/',contact,name='contact'),

    
]