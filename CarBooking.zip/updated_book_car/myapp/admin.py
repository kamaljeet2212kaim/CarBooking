from django.contrib import admin
from .models import *
from .models import Contact
# Register your models here.


admin.site.register(Emp)

class CarAdmin(admin.ModelAdmin):
    list_display = ('car_name','model_of_car','manufactured_by','Brand','Price')
    list_filter =  ('car_name',)
    search_fields = ('car_name',)
admin.site.register(Car,CarAdmin)


admin.site.register(Contact)