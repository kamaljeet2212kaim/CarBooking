from django.shortcuts import render,HttpResponse,redirect,get_object_or_404,reverse
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login,logout,authenticate
from django.contrib import auth
from django.db.models import Q
from .models import *
# Create your views here.

def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username,password=password)
        if user is not None:
            auth.login(request,user)
            return redirect('index')

    else:
            return render(request,'login.html')
            # if not request.user.is_authenticated:
            #      return redirect('login')
            # return render(request,'login.html')
def signup(request):
    frm = UserCreationForm()
    if request.method == 'POST':
         frm = UserCreationForm(request.POST)
         if frm.is_valid():
              frm.save()
              return redirect('/')
    return render(request,'signup.html',{'fm':frm})





def index(request):
    return render(request, 'index.html')


def car(request):     
    cars = Car.objects.all() 
    return render(request, 'car.html', {'cars':cars})


def car_details(request, car_id):
     car = get_object_or_404(Car,id = car_id)
     similar_cars = Car.objects.exclude(id=car_id)
     return render(request, 'details.html',{'car': car,'similar_cars':similar_cars})




def car(request):
    query = request.GET.get('q', '')  # Get the search query from the URL
    if query:
        cars = Car.objects.filter(model__icontains=query)  # Filter cars based on the search query
    else:
        cars = Car.objects.all()  # No search query, return all cars
    return render(request, 'car.html', {'cars': cars, 'query': query})

def aboutus(request):
     return render(request,'aboutus.html')

def contact(request):
    if request.method== 'POST':
        name= request.POST.get('name')
        email= request.POST.get('email')
        sub= request.POST.get('sub')
        message= request.POST.get('message')
        print(name,email,sub,message)
        user= Contact(name=name, email=email, sub=sub, message=message)
        user.save()
    return render(request,"contact.html")

def car_list(request):
     query = request.GET.get('q') 

     if query:
        #   Filter the cars based on the search term
        cars = Car.objects.filter(car_name__icontains=query)

     else:
         cars = Car.objects.all() # show all cars if no search term is entered

     return render(request,'car.html',{'cars':cars, 'query':query})
