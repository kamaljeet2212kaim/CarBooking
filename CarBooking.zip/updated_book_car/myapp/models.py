from django.db import models

# Create your models here.

class Emp(models.Model):
    Firstname=models.CharField(max_length=100)
    Lastname=models.CharField(max_length=100)
    Country=models.CharField(max_length=100)
    Age=models.IntegerField()

    def __str__(self):
        return self.Firstname

class Car(models.Model):
    
    car_name= models.CharField(max_length=150)
    model_of_car = models.CharField(max_length=100)
    manufactured_by = models.CharField(max_length=250)
    Brand = models.CharField(max_length=100)
    Price = models.CharField(max_length=50)
    image = models.ImageField(default=True)
    image1 = models.ImageField(default=True)
    image2 = models.ImageField(default=True)
    image3= models.ImageField(default=True)
    image4 = models.ImageField(default=True)


    
    def __str__(self):
        return self.car_name
    
class Contact(models.Model):
        name= models.CharField(max_length= 200,null=True)
        email= models.EmailField()
        sub= models.CharField(max_length=200,null=True)
        message= models.CharField(max_length= 200,null=True)

        def __str__(self):
            return self.name
    



